
import time

def main():
    print("Egon Buybot Lite is now running...")
    while True:
        time.sleep(10)

if __name__ == "__main__":
    main()
