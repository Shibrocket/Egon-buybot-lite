
# Egon Buybot Lite

Simple buy alert bot for Egon Chain.

## How to run

1. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the bot:
   ```bash
   python main.py
   ```
